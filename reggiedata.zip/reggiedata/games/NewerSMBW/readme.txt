NewerSMBW Reggie! Game Patch BETA
November 1, 2013
---------------------------------

For use with Reggie! Next.
Place this NewerSMBW folder into reggiedata/games and then restart Reggie!.

---------------------------------
Credits:
Sprite images by RoadrunnerWMC, Kamek64 and MalStar1000
Sprite data by ZementBlock/Ganjagrinda and joietyfull64
Levelnames by RoadrunnerWMC (ZementBlock also made a levelnames.txt independently)
Music list by RoadrunnerWMC
Tileset list originally created by ZementBlock; converted to XML format by RoadrunnerWMC
All of that compiled by RoadrunnerWMC
Reggie! Next itself by Treeki, Tempus and RoadrunnerWMC, with portions by JasonP27, MalStar1000, Kamek64, angelsl and everyone who made Reggie! r3.

And anybody else I may have forgotten.